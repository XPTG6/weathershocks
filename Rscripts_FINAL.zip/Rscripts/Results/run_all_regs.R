# Main results:
source("~/Rscripts/Results/Adm2_75_Reg.R") # Done

# Insights:
source("~/Rscripts/Results/Adm2_75_IntControls.R") # Done
source("~/Rscripts/Results/Adm2_75_ApproxPop.R") # Done
source("~/Rscripts/Results/Adm2_75_Conflict.R") # Done


# Other panels:
source("~/Rscripts/Results/Adm1_75_Reg.R") # Needs running

# source("~/Rscripts/Results/Main_Reg.R") # Not in use
