citation(c("data.table", "dplyr", "ggplot2", "zoo", "grid", "gridExtra",
"lemon", "SPEI", "RcppRoll",
"lfe", "rworldmap", "sp", "RCurl", "grid", "foreign", "xlsx", "stargazer",
"maptools", "maps", "shinydashboard", "DT", "reshape2", "plotly", "lubridate",
"devtools", "rNOMADS", "shinyjs", "dendextend", "ggdendro",
"raster", "ncdf4", "chron", "lubridate", "rasterVis", "rgdal", "geomerge",
"Rcpp", "countrycode", "snow", "cleangeo", "ggmap"))

citation()
citation("data.table")
citation("raster")
citation("sp")
citation("gridExtra")
citation("zoo")
citation("rgdal")
citation("reshape2")
citation("lemon")
citation("cleangeo")
citation("countrycode")
citation("maptools")
citation("stargazer")
citation("lfe")
citation("SPEI")
citation("ncdf4")
citation("ggplot2")
citation("RColorBrewer")
citation("viridis")
